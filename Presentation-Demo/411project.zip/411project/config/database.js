module.exports = {

    'url' : 'mongodb://wyf7107:z8f7c6n9@ds119748.mlab.com:19748/wyf7107_first_test' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};
